local MODE = MODE
MODE.NetSize_ChemicalResistanceBits = 8
MODE.ChemistNeutralizerDoses = 2
MODE.ChemistNeutralizerDuration = 45
MODE.ChemistNeutralizerReach = 90
MODE.LMSFinalStandMultiplier = 0.33
local chemical_degrade_speeds = {
	["HCN"] = 1,
	["KCN"] = 0.5,
}

MODE.DisarmReach = 70
MODE.NoDisarmWeapons = {
	["weapon_hands_sh"] = true,
}
MODE.ShadowCamouflageChargeTime = 4
MODE.ShadowCamouflageWallDistance = 25
MODE.ShadowCamouflageMoveSpeed = 15
MODE.ShadowCamouflageGraceTime = 1
MODE.ShadowCamouflageAlpha = 82
MODE.ShadowCamouflageTint = Color(190, 205, 220, 82)
MODE.ShadowCamouflageBlend = 0.52
MODE.ShadowCamouflageColorModulation = {
	0.78,
	0.84,
	0.94
}
MODE.FiberwireHeadSawTime = 3.5
MODE.NeckBreakReach = 65
MODE.NeckBreakDuration = 0.45
MODE.NeckBreakAttemptCooldown = 0.25
MODE.NeckBreakSuccessCooldown = 1
MODE.StalkerMarkMax = 3
MODE.StalkerMarkTime = 0.85
MODE.StalkerMarkDistance = 3300
MODE.StalkerMarkAngleCos = math.cos(math.rad(24))
MODE.StalkerMarkAssistDistance = 105
MODE.StalkerFirstHitStunTime = 1.65
MODE.StalkerIsolatedFirstHitStunTime = 2.75
MODE.StalkerIsolatedRadius = 360
MODE.StalkerFirstHitStaminaDrain = 60
MODE.StalkerFirstHitDamageMultiplier = 1.15
MODE.StalkerIsolatedFirstHitDamageMultiplier = 1.4
MODE.StalkerPursuitRadius = 1750
MODE.StalkerPursuitStaminaRegen = 14
MODE.StalkerPursuitFootstepVolume = 0.18
MODE.ManiacRampageMaxStacks = 5
MODE.ManiacRampageDuration = 15
MODE.ManiacRampageMoveSpeedPerStack = 0.03
MODE.ManiacRampageMeleeDamagePerStack = 0.06
MODE.ManiacRampageMeleeSpeedPerStack = 0.04
MODE.ManiacInjuryDefianceMoveFloor = 0.65
MODE.ManiacInjuryDefianceGripFloor = 0.70
MODE.CannibalConsumeTime = 4
MODE.CannibalCleaverConsumeTime = 2.75
MODE.CannibalConsumeReach = 100
MODE.CannibalHealthRestore = 40
MODE.CannibalBloodRestore = 900
MODE.CannibalStaminaBonusPerBody = 40
MODE.CannibalMeleeDamageBonusPerBody = 0.25
MODE.CannibalMaxConsumedBodies = 6
MODE.RevenantImplantTime = 2
MODE.RevenantPossessionTime = 32
MODE.RevenantBootDuration = 2
MODE.RevenantPossessionCooldown = 15
MODE.RevenantCharges = 3
MODE.RevenantImplantReach = 100
MODE.RevenantLootLockTime = 5
MODE.RevenantOriginalBodyHealth = 180
MODE.RevenantOriginalBodyDamageMul = 0.35
MODE.JuggernautModelScale = 1.15
MODE.JuggernautStaminaMultiplier = 2
MODE.JuggernautMeleeDamageMultiplier = 1.5
MODE.JuggernautLegStrengthMultiplier = 1.5
MODE.JuggernautJumpPowerMultiplier = 1.15
MODE.JuggernautStaminaExhaustMultiplier = 0.7
MODE.JuggernautStrangleTime = 3.25
MODE.JuggernautStrangleMinBrainOxygen = 0.12
MODE.JuggernautStrangleMinConsciousness = 0.2
MODE.JuggernautStrangleFinishStunTime = 7
MODE.JuggernautStrangleBlackoutTime = 12
MODE.JuggernautImpactMinSpeed = 340
MODE.JuggernautImpactCooldown = 1.25
MODE.JuggernautImpactDamage = 18
MODE.JuggernautImpactStunTime = 1.4
MODE.JuggernautStompReach = 105
MODE.JuggernautStompCooldown = 1.35
MODE.JuggernautStompMinPitch = 58

function MODE.IsShadowRole(subrole)
	return subrole == "traitor_stalker" or subrole == "traitor_stalker_soe"
		or subrole == "traitor_shadow" or subrole == "traitor_shadow_soe"
end

function MODE.IsStalkerRole(subrole)
	return subrole == "traitor_stalker" or subrole == "traitor_stalker_soe"
		or subrole == "traitor_shadow" or subrole == "traitor_shadow_soe"
end

function MODE.IsManiacRole(subrole)
	return subrole == "traitor_maniac" or subrole == "traitor_maniac_soe"
end

function MODE.IsCannibalRole(subrole)
	return subrole == "traitor_cannibal" or subrole == "traitor_cannibal_soe"
end

function MODE.IsRevenantRole(subrole)
	return subrole == "traitor_revenant" or subrole == "traitor_revenant_soe"
end

function MODE.GetRevenantPassengerOwner(body)
	if not IsValid(body) or not body:IsRagdoll() or not body:GetNWBool("HMCD_RevenantLiveEligible", false) then return nil end

	local owner = hg and hg.RagdollOwner and hg.RagdollOwner(body) or body:GetNWEntity("ply", NULL)
	if not IsValid(owner) or not owner:IsPlayer() or not owner:Alive() then return nil end
	if owner:GetNWBool("HMCD_RevenantPassenger", false) then return nil end

	return owner
end

function MODE.GetRevenantCorpseTarget(ply)
	if not IsValid(ply) or not MODE.IsRevenantRole(ply.SubRole) then return nil end

	local trace = hg and hg.eyeTrace and hg.eyeTrace(ply, MODE.RevenantImplantReach or 100)
	local corpse = trace and trace.Entity
	if not IsValid(corpse) or not corpse:IsRagdoll() then return nil end
	if corpse:GetNWBool("HMCD_RevenantUsed", false) then return nil end
	local passenger = MODE.GetRevenantPassengerOwner(corpse)
	if not IsValid(passenger) and not corpse:GetNWBool("HMCD_RevenantEligible", false) then return nil end

	return corpse, trace, passenger
end

function MODE.GetRevenantImplantProgress(ply)
	if not IsValid(ply) then return 0 end
	local started = ply:GetNWFloat("HMCD_RevenantImplantStart", 0)
	local ready = ply:GetNWFloat("HMCD_RevenantImplantReadyAt", 0)
	if started <= 0 or ready <= started then return 0 end
	return math.Clamp((CurTime() - started) / (ready - started), 0, 1)
end

function MODE.GetChemistNeutralizerTarget(ply)
	if not IsValid(ply) then return nil end

	local aim_ent, target, trace = MODE.GetPlayerTraceToOther(ply, nil, MODE.ChemistNeutralizerReach)
	if not IsValid(aim_ent) then return nil end

	if hg and hg.RagdollOwner then
		target = hg.RagdollOwner(aim_ent) or target
	end
	if not IsValid(target) and aim_ent:IsPlayer() then
		target = aim_ent
	end

	if not IsValid(target) or not target:IsPlayer() or target == ply or not target:Alive() then return nil end
	if not target.isTraitor and target ~= ply.HMCD_ChemistNeutralizerTarget then return nil end

	return target, aim_ent, trace
end

function MODE.IsJuggernautRole(subrole)
	return subrole == "traitor_juggernaut" or subrole == "traitor_juggernaut_soe"
end

function MODE.GetPlayerScaleForJuggernaut(ply)
	if not IsValid(ply) then return 1 end
	if hg and hg.GetPlayerModelScale then return hg.GetPlayerModelScale(ply) or 1 end

	return ply.GetModelScale and ply:GetModelScale() or 1
end

function MODE.IsJuggernautVictimSmallEnough(juggernaut, victim)
	if not IsValid(juggernaut) or not IsValid(victim) then return false end
	if victim.Profession == "athlete" then return false end

	local juggernaut_scale = MODE.GetPlayerScaleForJuggernaut(juggernaut)
	local victim_scale = MODE.GetPlayerScaleForJuggernaut(victim)

	return victim_scale < juggernaut_scale - 0.04
end

function MODE.GetJuggernautCarryTarget(ply)
	if not IsValid(ply) or not MODE.IsJuggernautRole(ply.SubRole) then return nil end

	local wep = ply:GetActiveWeapon()
	if not IsValid(wep) or wep:GetClass() ~= "weapon_hands_sh" or not wep.GetCarrying then return nil end

	local carried = wep:GetCarrying()
	if not IsValid(carried) then
		carried = ply:GetNetVar("carryent")
	end

	if not IsValid(carried) then return nil end

	local victim = carried:IsPlayer() and carried or ((hg and hg.RagdollOwner and hg.RagdollOwner(carried)) or carried.ply)
	if not IsValid(victim) or not victim:IsPlayer() or victim == ply or not victim:Alive() then return nil end
	if not MODE.IsJuggernautVictimSmallEnough(ply, victim) then return nil end

	return carried, victim
end

function MODE.CanJuggernautStrangle(ply)
	local carried, victim = MODE.GetJuggernautCarryTarget(ply)
	return IsValid(carried) and IsValid(victim), carried, victim
end

function MODE.GetJuggernautStrangleProgress(ply)
	if not IsValid(ply) then return 0 end

	local ready_at = ply:GetNWFloat("HMCD_JuggernautStrangleReadyAt", 0)
	local start_at = ply:GetNWFloat("HMCD_JuggernautStrangleStart", 0)
	if ready_at <= start_at or ready_at <= 0 then return 0 end

	return math.Clamp(1 - ((ready_at - CurTime()) / (ready_at - start_at)), 0, 1)
end

function MODE.GetJuggernautStompTarget(ply)
	if not IsValid(ply) or not MODE.IsJuggernautRole(ply.SubRole) then return nil end
	if ply:EyeAngles()[1] < (MODE.JuggernautStompMinPitch or 58) then return nil end

	local trace = hg and hg.eyeTrace and hg.eyeTrace(ply, MODE.JuggernautStompReach or 105)
	if not trace then return nil end

	local ent = trace.Entity
	if not IsValid(ent) then return nil end

	local victim
	local rag
	if ent:IsPlayer() then
		victim = ent
		rag = IsValid(victim.FakeRagdoll) and victim.FakeRagdoll or (victim.GetNWEntity and victim:GetNWEntity("FakeRagdoll", NULL))
	elseif ent:IsRagdoll() then
		rag = ent
		victim = (hg and hg.RagdollOwner and hg.RagdollOwner(ent)) or ent.ply
	else
		return nil
	end

	if not IsValid(victim) or not victim:IsPlayer() or victim == ply or not victim:Alive() then return nil end
	if not IsValid(rag) or not rag:IsRagdoll() then return nil end
	if not victim.organism or victim.organism.otrub ~= true then return nil end

	local head = rag:LookupBone("ValveBiped.Bip01_Head1")
	if head then
		local head_pos = rag:GetBonePosition(head)
		if head_pos and trace.HitPos:DistToSqr(head_pos) > 34 ^ 2 then return nil end
	end

	return rag, victim, trace, head
end

function MODE.IsCannibalCleaverEquipped(ply)
	local wep = IsValid(ply) and ply:GetActiveWeapon() or nil
	return IsValid(wep) and wep:GetClass() == "weapon_hg_cleaver"
end

function MODE.GetCannibalConsumeTime(ply)
	if MODE.IsCannibalCleaverEquipped and MODE.IsCannibalCleaverEquipped(ply) then
		return MODE.CannibalCleaverConsumeTime or 3
	end

	return MODE.CannibalConsumeTime or 4
end

function MODE.IsCannibalConsumableVictim(victim, corpse)
	if not IsValid(victim) or not victim:IsPlayer() then return false end
	if IsValid(corpse) and (corpse.HMCDCannibalConsumed or (corpse.GetNWBool and corpse:GetNWBool("HMCD_CannibalConsumed", false))) then return false end
	if not victim:Alive() then return true end

	local fake_ragdoll = IsValid(victim.FakeRagdoll) and victim.FakeRagdoll or (victim.GetNWEntity and victim:GetNWEntity("FakeRagdoll", NULL))
	if not IsValid(fake_ragdoll) then return false end
	if IsValid(corpse) and fake_ragdoll ~= corpse then return false end

	local org = victim.organism
	if SERVER then
		return org and org.otrub == true
	end

	return not org or org.otrub == true
end

function MODE.GetCannibalConsumeTarget(ply)
	if not IsValid(ply) then return nil end

	local trace = hg and hg.eyeTrace and hg.eyeTrace(ply, MODE.CannibalConsumeReach or 95)
	if not trace then return nil end

	local corpse = trace.Entity
	if not IsValid(corpse) then return nil end

	local victim
	if corpse:IsPlayer() then
		victim = corpse
		corpse = IsValid(victim.FakeRagdoll) and victim.FakeRagdoll or (victim.GetNWEntity and victim:GetNWEntity("FakeRagdoll", NULL))
	elseif corpse:IsRagdoll() then
		victim = (hg and hg.RagdollOwner and hg.RagdollOwner(corpse)) or corpse.ply
	else
		return nil
	end

	if not IsValid(corpse) or not corpse:IsRagdoll() then return nil end
	if CLIENT and not IsValid(victim) then
		return corpse, nil, trace
	end
	if not IsValid(victim) or not victim:IsPlayer() or victim == ply then return nil end
	if not MODE.IsCannibalConsumableVictim(victim, corpse) then return nil end

	return corpse, victim, trace
end

function MODE.GetCannibalConsumeProgress(ply)
	if not IsValid(ply) then return 0 end

	local ready_at = ply:GetNWFloat("HMCD_CannibalConsumeReadyAt", 0)
	local start_at = ply:GetNWFloat("HMCD_CannibalConsumeStart", 0)
	if ready_at <= start_at or ready_at <= 0 then return 0 end

	return math.Clamp(1 - ((ready_at - CurTime()) / (ready_at - start_at)), 0, 1)
end

function MODE.GetActiveFiberwire(ply)
	local wep = IsValid(ply) and ply:GetActiveWeapon() or nil
	if not IsValid(wep) or wep:GetClass() ~= "weapon_hg_fiberwire" then return nil end

	return wep
end

function MODE.IsPlayerUsingFiberwire(ply)
	return IsValid(MODE.GetActiveFiberwire(ply))
end

function MODE.GetFiberwireSawTarget(ply)
	local wep = MODE.GetActiveFiberwire(ply)
	if not IsValid(wep) or not wep.GetStrangling or not wep:GetStrangling() then return nil end

	local rag = wep.StrangleRag
	if not IsValid(rag) or not rag:IsRagdoll() then return nil end

	local victim = (hg and hg.RagdollOwner and hg.RagdollOwner(rag)) or rag.ply
	if not IsValid(victim) or not victim:IsPlayer() or not victim:Alive() then return nil end

	return wep, rag, victim
end

function MODE.CanPlayerSawHeadWithFiberwire(ply, aim_ent, other_ply)
	local _, rag, victim = MODE.GetFiberwireSawTarget(ply)
	if not IsValid(rag) or not IsValid(victim) then return false end
	if IsValid(aim_ent) and aim_ent ~= rag and aim_ent ~= victim then return false end
	if IsValid(other_ply) and other_ply ~= victim then return false end

	return true
end

function MODE.GetNeckBreakAction(ply)
	if ply.Ability_NeckBreak and ply.Ability_NeckBreak.Action then
		return ply.Ability_NeckBreak.Action
	end

	local wep = MODE.GetActiveFiberwire(ply)
	return (IsValid(wep) and wep.GetStrangling and wep:GetStrangling()) and "saw_head" or "neck_break"
end

function MODE.IsNeckBreakerRole(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if not ply.isTraitor then return false end

	return ply.SubRole == "traitor_infiltrator" or ply.SubRole == "traitor_infiltrator_soe"
end

function MODE.IsNeckBreakRoundActive()
	if CLIENT then return true end

	local active_mode = CurrentRound and CurrentRound()
	return active_mode == MODE and zb and zb.ROUND_STATE == 1
end

--\\
function MODE.GetPlayerTraceToOtherVictim(ply, victim, dist)
	if(IsValid(victim))then
		local ragdoll = victim.FakeRagdoll or victim:GetNWEntity("RagdollDeath", victim.FakeRagdoll)
		
		if(IsValid(ragdoll))then
			--
		else
			ragdoll = victim
		end
		
		local bone_id = ragdoll:LookupBone("ValveBiped.Bip01_Spine2")
		
		if(bone_id)then
			local bone_matrix = ragdoll:GetBoneMatrix(bone_id)
			
			if(bone_matrix)then
				local pos, ang = bone_matrix:GetTranslation(), bone_matrix:GetAngles()
				local ply_offset_normal = pos - ply:GetShootPos()
				local ply_aim_normal = ply:GetAimVector()
					
				ply_offset_normal:Normalize()
				ply_aim_normal:Normalize()
				
				local ang_diff = -(math.deg(math.acos(math.Clamp(ply_aim_normal:DotProduct(-ply_offset_normal), -1, 1))) - 180)
				
				if(ang_diff < 80)then
					local aim_ent, other_ply, trace = MODE.GetPlayerTraceToOther(ply, ply_offset_normal, dist)
					
					if(IsValid(aim_ent))then
						return aim_ent, other_ply, trace
					else
						return MODE.GetPlayerTraceToOther(ply, nil, dist)
					end
				else
					return MODE.GetPlayerTraceToOther(ply, nil, dist)
				end
			end
		end
	end
end
--

--\\Neck Break
function MODE.CanPlayerBreakOtherNeck(ply, aim_ent)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
	if not IsValid(aim_ent) or (not aim_ent:IsPlayer() and not aim_ent:IsRagdoll()) then return false end

	local wep = ply:GetActiveWeapon()
    if not IsValid(wep) or wep:GetClass() ~= "weapon_hands_sh" then return false end

	if(aim_ent:IsRagdoll())then
		local bone_id = aim_ent:LookupBone("ValveBiped.Bip01_Head1")
		
		if(bone_id)then
			local bone_matrix = aim_ent:GetBoneMatrix(bone_id)
			
			if(bone_matrix)then
				local pos, ang = bone_matrix:GetTranslation(), bone_matrix:GetAngles()
				local other_normal = -ang:Right()
				local ply_normal = pos - ply:GetShootPos()
				local dist_z = math.abs(pos.z - ply:GetShootPos().z)
				
				if(dist_z < 50) then
					ply_normal:Normalize()
					
					local ang_diff = -(math.deg(math.acos(math.Clamp(ply_normal:DotProduct(other_normal), -1, 1))) - 180)
					
					if(ang_diff < 100)then
						return true
					end
				end
			end
		end
	elseif(aim_ent:IsPlayer())then
		local other_angle = aim_ent:EyeAngles()[2]
		local ply_angle = (aim_ent:GetPos() - ply:GetPos()):Angle()[2] --ply:EyeAngles()[2]
		local ang_diff = math.abs(math.AngleDifference(other_angle, ply_angle))
		
		if(ang_diff < 100)then
			return true
		end
	end
	
	return false
end

function MODE.ValidateNeckBreakInteraction(ply, victim, action, require_keys)
	if not SERVER then return false end
	if not MODE.IsNeckBreakRoundActive() or not MODE.IsNeckBreakerRole(ply) then return false end
	if not IsValid(ply) or not ply:Alive() or not ply.organism or ply.organism.otrub or ply:InVehicle() then return false end
	if not IsValid(victim) or not victim:IsPlayer() or victim == ply or not victim:Alive() then return false end
	if require_keys and (not ply:KeyDown(IN_WALK) or not ply:KeyDown(IN_USE)) then return false end

	action = action or "neck_break"
	if action ~= "neck_break" and action ~= "saw_head" then return false end

	local current_attacker = victim.HMCDNeckBreakAttacker
	if victim.BeingVictimOfNeckBreak and current_attacker ~= ply then return false end
	if IsValid(current_attacker) and current_attacker ~= ply then return false end

	if action == "saw_head" then
		local _, rag, saw_victim = MODE.GetFiberwireSawTarget(ply)
		if saw_victim ~= victim or not MODE.CanPlayerSawHeadWithFiberwire(ply, rag, saw_victim) then return false end

		return true, rag
	end

	local aim_ent, traced_victim, trace = MODE.GetPlayerTraceToOtherVictim(ply, victim, MODE.NeckBreakReach)
	if IsValid(aim_ent) and traced_victim ~= victim and hg and hg.RagdollOwner then
		traced_victim = hg.RagdollOwner(aim_ent) or traced_victim
	end
	if not IsValid(aim_ent) or traced_victim ~= victim or not trace then return false end
	if not trace.HitPos or ply:GetShootPos():DistToSqr(trace.HitPos) > (MODE.NeckBreakReach + 8) ^ 2 then return false end
	if not MODE.CanPlayerBreakOtherNeck(ply, aim_ent) then return false end

	return true, aim_ent
end

function MODE.BreakOtherNeck(ply, other_ply, aim_ent)
	if not SERVER then return false end
	local function reject(reason)
		if IsValid(ply) and (ply.HMCDNextNeckBreakSecurityLog or 0) <= CurTime() then
			ply.HMCDNextNeckBreakSecurityLog = CurTime() + 2
			ServerLog(string.format("[HMCD SECURITY] Rejected neck snap from %s [%s]: %s\n", ply:Nick(), ply:SteamID(), reason))
		end

		return false
	end

	local break_data = IsValid(ply) and ply.Ability_NeckBreak
	if not istable(break_data) or break_data.Victim ~= other_ply or break_data.Action ~= "neck_break" then return reject("missing or mismatched interaction state") end
	if break_data.Completing or CurTime() + 0.001 < (break_data.ReadyAt or math.huge) then return reject("interaction completed too early or more than once") end

	local valid, validated_ent = MODE.ValidateNeckBreakInteraction(ply, other_ply, "neck_break", true)
	if not valid or not IsValid(validated_ent) then return reject("role, round, input, range, line-of-sight, or target validation failed") end
	aim_ent = validated_ent

	break_data.Completing = true
	if(other_ply:Alive())then
		ServerLog(string.format("[HMCD] %s [%s] neck-snapped %s [%s] at %s\n", ply:Nick(), ply:SteamID(), other_ply:Nick(), other_ply:SteamID(), tostring(other_ply:GetPos())))
		other_ply:Kill()
		other_ply:ViewPunch(Angle(0, 0, -10))
		
		if IsValid(aim_ent) and aim_ent.organism then
			aim_ent.organism.spine3 = 1
		end
		
		aim_ent:EmitSound("neck_snap_01.wav", 60, 100, 1, CHAN_AUTO)

		timer.Simple(0.1, function()
			local ent = other_ply:GetNWEntity("RagdollDeath")

			if IsValid(ent) then
				ent:RemoveInternalConstraint(ent:TranslateBoneToPhysBone(ent:LookupBone("ValveBiped.Bip01_Head1")))

				local spine = ent:TranslateBoneToPhysBone(ent:LookupBone("ValveBiped.Bip01_Spine2"))
				local head = ent:TranslateBoneToPhysBone(ent:LookupBone("ValveBiped.Bip01_Head1"))

				local pspine = ent:GetPhysicsObjectNum(spine)
				local phead = ent:GetPhysicsObjectNum(head)

				local lpos, lang = WorldToLocal(phead:GetPos() + phead:GetAngles():Forward() * -2 + phead:GetAngles():Up() * -1.5, angle_zero, pspine:GetPos(), pspine:GetAngles())
                
				phead:SetPos(pspine:GetPos() + pspine:GetAngles():Forward() * 12.9 + pspine:GetAngles():Right() * -1)

				local cons = constraint.AdvBallsocket(ent, ent, spine, head, lpos, nil, 0, 0, -55, -90, -50, 55, 35, 50, 0, 0, 0, 0, 0)
			end
		end)
	end

	return true
end

function MODE.SawOffOtherHead(ply, other_ply, aim_ent)
	local function resolveRagdoll(allow_fallback)
		if IsValid(other_ply) then
			local death_rag = other_ply:GetNWEntity("RagdollDeath")
			if IsValid(death_rag) and death_rag:IsRagdoll() then return death_rag end

			if IsValid(other_ply.RagdollDeath) and other_ply.RagdollDeath:IsRagdoll() then
				return other_ply.RagdollDeath
			end
		end

		if allow_fallback and IsValid(aim_ent) and aim_ent:IsRagdoll() then return aim_ent end
	end

	local function finishRagdoll(rag)
		if not IsValid(rag) or not rag:IsRagdoll() then return end
		if rag.FiberwireHeadSawDone then return end

		local head = rag:LookupBone("ValveBiped.Bip01_Head1")
		if not head then return end

		local phys_bone = rag:TranslateBoneToPhysBone(head)
		if not phys_bone or phys_bone < 0 then return end
		local phys = rag:GetPhysicsObjectNum(phys_bone)
		rag.FiberwireHeadSawDone = true

		if IsValid(phys) then
			phys:AddVelocity((ply:GetAimVector() + Vector(0, 0, 0.35)) * 90)
		end

		local force = IsValid(ply) and ((ply:GetAimVector() + Vector(0, 0, 0.25)) * 450) or vector_origin
		if Gib_Input then
			Gib_Input(rag, head, force)
		elseif Gib_RemoveBone then
			Gib_RemoveBone(rag, head, phys_bone)
		else
			rag:RemoveInternalConstraint(phys_bone)
			rag:ManipulateBoneScale(head, vector_origin)
		end

		local pos = rag:GetBonePosition(head) or rag:WorldSpaceCenter()
		if SpawnMeatGore and not Gib_Input then
			SpawnMeatGore(rag, pos or rag:WorldSpaceCenter(), 6)
		end

		rag:EmitSound("physics/flesh/flesh_squishy_impact_hard" .. math.random(1, 4) .. ".wav", 70, math.random(75, 90), 1)
	end

	if IsValid(aim_ent) and aim_ent.organism then
		aim_ent.organism.spine3 = 1
	end

	if IsValid(other_ply) and other_ply:Alive() then
		other_ply:Kill()
	end

	local timer_id = "HMCD_FiberwireHeadSaw_" .. tostring(IsValid(other_ply) and other_ply:EntIndex() or IsValid(aim_ent) and aim_ent:EntIndex() or 0)
	local tries = 0
	timer.Create(timer_id, 0.05, 24, function()
		tries = tries + 1
		local rag = resolveRagdoll(tries > 6)
		if not IsValid(rag) then return end

		finishRagdoll(rag)
		timer.Remove(timer_id)
	end)
end

function MODE.StartBreakingOtherNeck(ply, other_ply, action)
	if not IsValid(ply) or not IsValid(other_ply) or not other_ply:IsPlayer() or ply == other_ply then return false end

	action = action or "neck_break"
	if action ~= "neck_break" and action ~= "saw_head" then return false end

	local now = CurTime()
	local duration = action == "saw_head" and MODE.FiberwireHeadSawTime or MODE.NeckBreakDuration

	if SERVER then
		if (ply.HMCDNextNeckBreakAttempt or 0) > now then return false end
		ply.HMCDNextNeckBreakAttempt = now + MODE.NeckBreakAttemptCooldown

		local valid = MODE.ValidateNeckBreakInteraction(ply, other_ply, action, true)
		if not valid then return false end

		if ply.Ability_NeckBreak then
			MODE.StopBreakingOtherNeck(ply)
		end

		other_ply.HMCDNeckBreakAttacker = ply
	end

	ply.Ability_NeckBreak = {
		Victim = other_ply,
		Progress = 0,
		Action = action,
		StartedAt = now,
		ReadyAt = now + duration,
	}
	other_ply.BeingVictimOfNeckBreak = true
	
	if(SERVER)then
		other_ply:ViewPunch(Angle(0, -10, -10))
		
		net.Start("HMCD_BeingVictimOfNeckBreak")
			net.WriteBool(true)
		net.Send(other_ply)
		
		net.Start("HMCD_BreakingOtherNeck")
			net.WriteBool(true)
			net.WriteEntity(ply)
			 net.WriteEntity(other_ply)
			net.WriteString(ply.Ability_NeckBreak.Action)
		net.SendPVS(ply:GetShootPos())
	end

	return true
end

function MODE.StopBreakingOtherNeck(ply)
	if not IsValid(ply) then return end

	local break_data = ply.Ability_NeckBreak
	local victim = break_data and break_data.Victim
	if IsValid(victim) and (not SERVER or victim.HMCDNeckBreakAttacker == ply) then
		victim.BeingVictimOfNeckBreak = false
		if SERVER then victim.HMCDNeckBreakAttacker = nil end
	end
	
	if(SERVER and break_data and IsValid(victim))then
		net.Start("HMCD_BeingVictimOfNeckBreak")
			net.WriteBool(false)
		net.Send(victim)

		net.Start("HMCD_BreakingOtherNeck")
			net.WriteBool(false)
			net.WriteEntity(ply)
		net.SendPVS(ply:GetShootPos())
	end
	
	ply.Ability_NeckBreak = nil
end

function MODE.ContinueBreakingOtherNeck(ply)
	local break_data = ply.Ability_NeckBreak
	if not istable(break_data) then return end

	local victim = break_data.Victim
	local action = break_data.Action or "neck_break"
	local now = CurTime()
	local started_at = break_data.StartedAt or now
	local ready_at = break_data.ReadyAt or (started_at + (action == "saw_head" and MODE.FiberwireHeadSawTime or MODE.NeckBreakDuration))
	local duration = math.max(ready_at - started_at, 0.01)
	break_data.Progress = math.Clamp((now - started_at) / duration * 100, 0, 100)

	if CLIENT then
		if now > ready_at + 1 then MODE.StopBreakingOtherNeck(ply) end
		return
	end

	local can_continue, aim_ent = MODE.ValidateNeckBreakInteraction(ply, victim, action, true)
	if can_continue then

			if(action == "saw_head" and (break_data.NextSawSound or 0) <= now)then
				break_data.NextSawSound = now + 0.75
				aim_ent:EmitSound("physics/flesh/flesh_squishy_impact_hard" .. math.random(1, 4) .. ".wav", 55, math.random(80, 95), 0.45)

				if hg and hg.organism and hg.organism.AddWoundManual and aim_ent.organism then
					local head = aim_ent:LookupBone("ValveBiped.Bip01_Head1")
					if head then
						hg.organism.AddWoundManual(aim_ent, 18, vector_origin, angle_zero, head, CurTime())
					end
				end
			end
			
			if(now >= ready_at)then
				local completed
				if(action == "saw_head")then
					MODE.SawOffOtherHead(ply, victim, aim_ent)
					completed = true
				else
					completed = MODE.BreakOtherNeck(ply, victim, aim_ent)
				end

				if completed then
					ply.HMCDNextNeckBreakAttempt = now + MODE.NeckBreakSuccessCooldown
				end
				MODE.StopBreakingOtherNeck(ply)
			end
	else
		MODE.StopBreakingOtherNeck(ply)
	end
end

hook.Add("HG_MovementCalc_2", "HMCD_SubRole_Abilities", function(mul, ply, cmd)
	if(ply.BeingVictimOfNeckBreak or ply.BeingVictimOfDisarmament)then
		mul[1] = mul[1] * 0.3
	end

	if(ply.Ability_CannibalConsume)then
		mul[1] = mul[1] * 0.25
	end

	if(ply.Ability_JuggernautStrangle)then
		mul[1] = mul[1] * 0.45
	end

	if(ply:GetNWBool("HMCD_ManiacFuryActive", false))then
		if not ply.HMCDManiacRampageModifiersApplied then
			ply.HMCDManiacRampageModifiersApplied = true
			ply.HMCDManiacBaseMeleeDamageMul = ply.MeleeDamageMul or 1
			ply.HMCDManiacBaseMeleeSpeedMul = ply.MeleeSpeedMul or 1
		end

		local stacks = math.Clamp(ply:GetNWInt("HMCD_ManiacRampageStacks", 0), 0, MODE.ManiacRampageMaxStacks or 5)
		ply.MeleeDamageMul = ply.HMCDManiacBaseMeleeDamageMul * (1 + stacks * (MODE.ManiacRampageMeleeDamagePerStack or 0.06))
		ply.MeleeSpeedMul = ply.HMCDManiacBaseMeleeSpeedMul * (1 + stacks * (MODE.ManiacRampageMeleeSpeedPerStack or 0.04))
		mul[1] = mul[1] * (1 + stacks * (MODE.ManiacRampageMoveSpeedPerStack or 0.03))
	elseif ply.HMCDManiacRampageModifiersApplied then
		ply.MeleeDamageMul = ply.HMCDManiacBaseMeleeDamageMul
		ply.MeleeSpeedMul = ply.HMCDManiacBaseMeleeSpeedMul
		ply.HMCDManiacRampageModifiersApplied = nil
		ply.HMCDManiacBaseMeleeDamageMul = nil
		ply.HMCDManiacBaseMeleeSpeedMul = nil
	end
end)
--

--\\Disarm
function MODE.CanPlayerDisarmOtherPly(ply, other_ply)
	--[[if(other_ply and IsValid(other_ply:GetActiveWeapon()))then
		if(MODE.NoDisarmWeapons[other_ply:GetActiveWeapon():GetClass()])then
			return false
		end
	else
		return false
	end--]]
	
	return true
end

function MODE.CanPlayerDisarmOther(ply, aim_ent)
	if(aim_ent:IsRagdoll())then
		local bone_id = aim_ent:LookupBone("ValveBiped.Bip01_Spine2")
		
		if(bone_id)then
			local bone_matrix = aim_ent:GetBoneMatrix(bone_id)
			
			if(bone_matrix)then
				local pos, ang = bone_matrix:GetTranslation(), bone_matrix:GetAngles()
				local other_normal = ang:Right()
				local ply_normal = pos - ply:GetShootPos()
				local dist_z = math.abs(pos.z - ply:GetShootPos().z)
				
				if(dist_z < 50) then
					ply_normal:Normalize()
					
					local ang_diff = -(math.deg(math.acos(ply_normal:DotProduct(other_normal))) - 180)
					
					if(ang_diff < 90)then
						return 2
					else
						return 1.5
					end
				end
			end
		end
	elseif(aim_ent:IsPlayer())then
		local other_angle = aim_ent:EyeAngles()[2]
		local ply_angle = (aim_ent:GetPos() - ply:GetPos()):Angle()[2] --ply:EyeAngles()[2]
		local ang_diff = math.abs(math.AngleDifference(other_angle, ply_angle))
		
		if(ang_diff < 70)then
			return 2
		else
			return 1.5
		end
	end
	
	return false
end

function MODE.DisarmOther(ply, other_ply, aim_ent)
	if(other_ply:Alive())then
		local weapon = other_ply:GetActiveWeapon()

		if(IsValid(weapon) and !weapon.NoDrop)then
			other_ply:DropWeapon(weapon)
			ply:PickupWeapon(weapon, false)
		end

		hg.LightStunPlayer(other_ply)
		timer.Simple(0,function()
			local rag = hg.GetCurrentCharacter(other_ply)
			if IsValid(rag) and rag ~= other_ply then
				local bon = rag:LookupBone("ValveBiped.Bip01_Head1")
				local physnum = rag:TranslateBoneToPhysBone(bon)
				local phys = rag:GetPhysicsObjectNum(physnum)
				local dist = 25--phys:GetPos():Distance(ply:EyePos())
				
				hg.SetCarryEnt2(ply, rag, bon, phys:GetMass(), Vector(-2,0,0), ply:GetAimVector() * dist + ply:EyeAngles():Up() * 5 + ply:EyeAngles():Right() * -5 + ply:GetShootPos(), ply:EyeAngles() + Angle(-90, 90, 0))
			end
		end)
	end
end

function MODE.StartDisarmingOther(ply, other_ply)
	ply.Ability_Disarm = {
		Victim = other_ply,
		Progress = 0,
	}
	other_ply.BeingVictimOfDisarmament = true
	
	if(SERVER)then
		-- other_ply:ViewPunch(Angle(0, -10, -10))
		
		net.Start("HMCD_BeingVictimOfDisarmament")
			net.WriteBool(true)
		net.Send(other_ply)
		
		net.Start("HMCD_DisarmingOther")
			net.WriteBool(true)
			net.WriteEntity(other_ply)
		net.Send(ply)
	end
end

function MODE.StopDisarmingOther(ply)
	if(ply.Ability_Disarm and IsValid(ply.Ability_Disarm.Victim))then
		ply.Ability_Disarm.Victim.BeingVictimOfDisarmament = false
	end
	
	if(SERVER and ply.Ability_Disarm and IsValid(ply.Ability_Disarm.Victim))then
		net.Start("HMCD_BeingVictimOfDisarmament")
			net.WriteBool(false)
		net.Send(ply.Ability_Disarm.Victim)

		net.Start("HMCD_DisarmingOther")
			net.WriteBool(false)
		net.Send(ply)
	end
	
	ply.Ability_Disarm = nil
end

function MODE.ContinueDisarmingOther(ply)
	local ability_data = ply.Ability_Disarm
	local victim = ability_data.Victim
	local aim_ent, other_ply, trace = MODE.GetPlayerTraceToOtherVictim(ply, victim, MODE.DisarmReach)
	
	if(IsValid(aim_ent) and (aim_ent:IsPlayer() or aim_ent:IsRagdoll()))then
		local disarm_strength = MODE.CanPlayerDisarmOther(ply, aim_ent)
		
		if(IsValid(victim) and victim:Alive() and disarm_strength and other_ply == victim and MODE.CanPlayerDisarmOtherPly(ply, other_ply))then
			ability_data.Progress = ability_data.Progress + FrameTime() * 250 * disarm_strength
			
			if(ability_data.Progress >= 100)then
				if(SERVER)then
					MODE.DisarmOther(ply, victim, aim_ent)
				end
				
				
				MODE.StopDisarmingOther(ply)
			end
		else
			MODE.StopDisarmingOther(ply)
		end
	else
		MODE.StopDisarmingOther(ply)
	end
end

hook.Add("PlayerSwitchWeapon", "HMCD_SubRole_Abilities", function(ply)
	if(ply.BeingVictimOfDisarmament)then
		return true
	end
end)
--
